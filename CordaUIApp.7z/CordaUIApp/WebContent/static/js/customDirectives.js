angular.module('bcloyalty').directive('publicHeader',function(){
	return{
		templateUrl:"static/partials/publicHeader.html"
	}
});


angular.module('bcloyalty').directive('footerDirective', function(){
	return{
		templateUrl:"static/partials/footer.html"
	}
});
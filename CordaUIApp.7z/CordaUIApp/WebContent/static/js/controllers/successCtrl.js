angular.module('bcloyalty').controller('successCtrl',function($scope,  $state){

	if($state.params.successMsg){
		$scope.successMsg = $state.params.successMsg;
	}

});
